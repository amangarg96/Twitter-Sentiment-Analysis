# -*- coding: utf-8 -*-

"""
Extracts all the adjectives of the tweets and stores them in a json file.
"""

#import gensim
import pandas as pd
import nltk
from scipy import spatial
import json
import nltk
import numpy as np

F = pd.read_csv('C:\\Users\\Tania Dey\\Desktop\\newproject\\tweetsfinal.csv',header=None)
F=F[2].values
print F
i=0
adjective={}
for i in range(8179):
    adj=[]
    try:
        if F[i]!=' ':
            
            word=nltk.word_tokenize(F[i])
            tag=nltk.pos_tag(word)
            #print tag
            j=0
            for j in range(len(tag)):
                if tag[j][1]=='JJ':
                    adj.append(tag[j][0])
                    
    except:
        print("error")
    adjective[i]=adj      
print adjective
filen='C:\\Users\\Tania Dey\\Desktop\\newproject\\adjective_list.json'
fop=open(filen,'w')
json.dump(adjective,fop)
fop.close()
