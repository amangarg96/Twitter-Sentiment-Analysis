# -*- coding: utf-8 -*-
"""
Created on Fri Jun 16 09:47:43 2017

@author: Amit Behera
"""

# Code to calculate Semantic Orientation scores of each of the adjectives found
# in each of the tweets for building the dictionary by Model 1
# The final output is a json file


import pandas as pd
import math
import json
import io
import csv
import multiprocessing
from SemOrient1 import SemOrient1
from SemOrient2 import SemOrient2
from SemOrient3 import SemOrient3
from SemOrient4 import SemOrient4
from string_freq_calc import string_freq_calc
#import time

#opening file and extracting sentences. storing the sentences in the list named match.
#t = time.time()

if __name__=='__main__':
    
    #Loads dictionary of phrases with the tweet number as its key
    ff=open('C:\Users\Amit Behera\.spyder\PROJECT\!Finals\data\words_adjective.json','r')
    ph=json.load(ff)
    so={}
    solist=[]
    filen='C:\Users\Amit Behera\.spyder\PROJECT\!Finals\data\So_adjectives\SO_ADJS1.json'
    f1=open(filen,'r')
    soll=json.load(f1)
    #print soll
    print len(soll)
    f1.close()
    phr={}
    #print len(ph)
    #print ph
    phr=ph
    '''
    #Taking only 2 tweets for our calculation
    for i in range(0,3):
        k=unicode(i)
        phr[k]=ph[k]'''
        
        
    #CALCULATION OF SEMANTIC ORIENTATION
    pos_seed = 'good'
    neg_seed = 'bad'

    pos_count = 188455#string_freq_calc(pos_seed)
    print pos_count  #188455
    neg_count = 122835#string_freq_calc(neg_seed)   
    print neg_count  #122835
    
    k1=len(soll)
    k2=0
    print phr
    for i in phr:
        k2=k2+1
        print 'Tweet Number: '+str(k2)
        if phr[i]!=[]:
            for p in phr[i]:
                k1=k1+1
                print 'Word Number: '+str(k1)
                print p
                print i
                try:
                    pl=str(p.encode('utf-8'))
                except:
                    pass
                #print pl
                #print type(pl)
                #r=SemanticOrientation(pl,'excellent','poor')   #Function call
                
                #Code for calculating Semantic Orientation with 4 Processes begins
                phrase = pl
                if (phrase not in soll):
                    Array_1 = multiprocessing.Array('d',2)
                    Array_2 = multiprocessing.Array('d',2)
                    Array_3 = multiprocessing.Array('d',2)
                    Array_4 = multiprocessing.Array('d',2)
                        
                    t1 = multiprocessing.Process(target=SemOrient1,args = (phrase,pos_seed,neg_seed,Array_1,))
                    t2 = multiprocessing.Process(target=SemOrient2,args = (phrase,pos_seed,neg_seed,Array_2,))
                    t3 = multiprocessing.Process(target=SemOrient3,args = (phrase,pos_seed,neg_seed,Array_3,))
                    t4 = multiprocessing.Process(target=SemOrient4,args = (phrase,pos_seed,neg_seed,Array_4,))
                    
                    #t_start_1 = time.time()
                    t1.start()
                    t2.start()
                    t3.start()
                    t4.start()
                    
                    #t_start_2 = time.time() - t_start_1
                    #print "Time taken for t.start():" +str(t_start_2)
                    
                    # t_join_1 = time.time()
                    t1.join()
                    t2.join()
                    t3.join()
                    t4.join()
                    # t_join_2 = time.time() - t_join_1
                    # print "Time taken for t.join():" + str(t_join_2)
                    
                    #elapsed = time.time() - t
    
    
                    # print Array_1[:]
                    # print Array_2[:]
                    # print Array_3[:]
                    # print Array_4[:]
    
                    phrase_post_count = Array_1[0] + Array_2[0] + Array_3[0] + Array_4[0]
                    phrase_neg_count = Array_1[1] + Array_2[1] + Array_3[1] + Array_4[1]
                    # phrase_count = Array_1[2] + Array_2[2] + Array_3[2] + Array_4[2]
                    # pos_count = Array_1[3] + Array_2[3] + Array_3[3] + Array_4[3]
                    # neg_count = Array_1[4] + Array_2[4] + Array_3[4] + Array_4[4]
    
                    #print "Phrase freq:" + str(phrase_count)
                    # print "Positive Seed count:" + str(pos_count)
                    # print "Negative Seed count:" + str(neg_count)
                    print "Phrase,Positive Seed count:" + str(phrase_post_count)
                    print "Phrase,Negative Seed count:" + str(phrase_neg_count)
                    
                    if phrase_post_count == 0.01 and phrase_neg_count == 0.01:
                        SO = 0
                    else:
                        SO = math.log(((phrase_post_count * neg_count) / (phrase_neg_count*pos_count)),2) # Log Base 2, as used in paper
                    
                    #Semantic Orientation for 
                    
                    print SO
                    solist.append(SO)
                    soll[phrase]=SO
                    filen='C:\Users\Amit Behera\.spyder\PROJECT\!Finals\data\So_adjectives\SO_ADJS1.json'
                    f=open(filen,'w')
                    json.dump(soll,f)
                    f.close()

                
        so[i]=solist   
        solist=[]

    #print so    #Dictionary containing calculated semantic orientation for each individual phrase
    #print soll
    # NUMBER OF ADJECTIVES : 15089
    
    '''
    sent_so={}
    #for i in so:
    #    sent_so[i]=(sum(so[i]))
    #    
    #print sent_so     #Dictionary containing sum of semantic orientation for each tweet
    #RESULT
    #sent_so={u'6796': 0, u'6797': -4.996407759328534, u'6794': 0.0863955294153543, u'6795': 0, u'6792': -1.1393858258286285, u'6793': -4.996407759328534, u'6790': 0, u'6791': 0, u'6798': -7.983854708985449, u'6799': -4.996407759328534}
    '''
    #filen='C:\Users\Amit Behera\.spyder\PROJECT\!Finals\data\So_adjectives\SO_ADJS1.json'
    #f=open(filen,'w')
    #json.dump(soll,f)
    #f.close()
    ff.close()
    
    
    
    
    #good: 4.48,excellent:2.25,amazing: 0.6225
    #bad:-5.5, poor:0.04, horrible=-1.15
    
    