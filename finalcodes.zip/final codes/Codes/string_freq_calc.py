#Calculates the frequency of a string in the Wikipedia Corpus. Has not been optimized, can be made more efficient using multiprocessing

import nltk
import pandas as pd
import re
import math
import time

#opening file and extracting sentences. storing the sentences in the list named match.

def string_freq_calc(String):
    String = String.lower()
    string_count = 0.01
    start = 0
    end = 10000

    for x in range(164):
        filename = "C:\Users\Aman Garg\Documents\\raw-en\englishText_%d_%d" %(start,end)
        file=open(filename,"r")
        sent=[line.lower() for line in file]
        se=' '.join(sent)
        match=re.split(r'[.!?]', se)

        for i in match:
            string_count = string_count + i.count(String)
        start = start + 10000
        end = end + 10000
    
    return string_count 

# Takes ~90 secs