# -*- coding: utf-8 -*-
"""
Created on Thu Jun 29 15:52:30 2017

@author: Amit Behera
"""
# Code to join each of the smaller dictionary of tweet-SO score and 
# forming a final dictionary comprising of all the SO scores and 
# writing it into a csv file
import pandas as pd
import json

a={}
for i in range(1,14):
    file='C:\Users\Amit Behera\.spyder\PROJECT\!Finals\data\So_tweets\SO_TWEETS%d.json'%i
    print file
    f=open(file,'r')
    d=json.load(f)
    f.close()
    for j in d:
        #print j
        a[j]=d[j]
        #print a

fil='C:\Users\Amit Behera\.spyder\PROJECT\!Finals\data\So_tweets\SO_TWEETS.csv'
df=pd.DataFrame({'No. Tweet':a.keys(),'SO':a.values()})
df.to_csv(fil,delimiter='\t',index=False)
#df=pd.DataFrame(a)