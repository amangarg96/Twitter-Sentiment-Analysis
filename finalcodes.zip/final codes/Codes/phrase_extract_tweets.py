# Extracts phrases using the rules mentioned in paper of Peter D.Turney Et. al

import pandas as pd
import nltk
import numpy as np


filen='C:\Users\Aman Garg\Desktop\Project\Codes\Final_set.csv'
df=pd.read_csv(filen,header=None)
tag=[]

def removeNonAscii(s): return "".join(filter(lambda x: ord(x)<128, s))

for s in df[2]:
    
    s.encode("ascii","ignore")
    #s=df[2][i]
    print s
    txt=nltk.word_tokenize(s)
    tag.append(nltk.pos_tag(txt))
    #print tag
    #for l in tag:
    #   print l[1]

k=-1
phrases={}
for t in tag:
    #print t
    t.append(('',''))
    t.append(('',''))
    #print t
    k=k+1
    ph=[]
    for x in range(len(t)-2):
        #print t[x]
        #ph=[]
        q1=t[x][1]
        q2=t[x+1][1]
        q3=t[x+2][1]
        w1=t[x][0]
        w2=t[x+1][0]
        w=w1+' '+w2
        if (q1=='JJ'):
            #print 1
            if (q2!=''):
                if(q2=='NN' or q2=='NNS'):
                    #print 2
                    #w1=t[x][0]
                    #w2=t[x+1][0]
                    #w=w1+' '+w2
                    #print w
                    ph.append(w)
                    #ph.append(k)
        if (q1=='RB' or q1=='RBR' or q1=='RBS'):
            if (q2=='JJ'):
                if (q3!='NN' and q3!='NNS'):
                    #print 3
                    ph.append(w)
                    #ph.append(k)
        
        if (q1=='JJ' and q2=='JJ' and q3!='NN' and q3!='NNS'):
            #print 4
            ph.append(w)
            #ph.append(k)
        
        if ((q1=='NN' or q1=='NNS') and (q2=='JJ') and (q3!='NN' and q3!='NNS')):
            #print 5
            ph.append(w)
            #ph.append(k)
            
        if((q1=='RB' or q1=='RBR' or q1=='RBS') and (q2=='VB' or q2=='VBD' or q2=='VBN' or q2=='VBG')):
            #print 6
            ph.append(w)
            #ph.append(k)
            
    
    #print 99
    phrases[k]=ph


df = pd.DataFrame(dict([ (k,pd.Series(v)) for k,v in phrases.iteritems() ]))
df=df.transpose()
df.to_csv('phrases_final_updated.csv')                        
                     
                    
                   
                   
                   
               
            