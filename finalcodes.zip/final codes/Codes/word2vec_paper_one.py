# Calculates Semantic Orientation of phrases using word2vec vectorization of phrases. 
# Phrases read from phrases_final_updated.json. Code - phrase_extract_tweets
# Takes phrases extracted from tweets as input (json dictionary), and stores Semantic Orientation in csv file
# Uses a pretrained model of word2vec (Trained on GoogleNews Dataset, released by Google) Link - https://drive.google.com/file/d/0B7XkCwpI5KDYNlNUTTlSS21pQmM/edit?usp=sharing
# Replaces Semantic Orientation using PMI to Cosine similarity between vectors

import pandas as pd 
from scipy import spatial 
import gensim.models
import json
import numpy as np 


ff=open('C:\Users\Aman Garg\Desktop\Project\Codes\phrases_final_updated.json','r') #Opening json file containing phrases extracted from tweets
ph=json.load(ff)
so={}
solist=[]
phr={}

# Loading pre-trained word2vec model, takes a couple of minutes to load
model = gensim.models.KeyedVectors.load_word2vec_format('C:\Users\Aman Garg\Documents\GoogleNewsDataset\GoogleNews-vectors-negative300.bin', binary=True)

pos_seed = 'good'
neg_seed = 'bad'
vec_pos = model[pos_seed] # Returns word2vec vectorization of string
vec_neg = model[neg_seed]
List_pred = []
List_SO = []
#print len(phr)
count = 0
not_found_counter = 0 # Counter for phrases not found in word2vec


for j in range(8000):
	k=unicode(j)
	phr[k]=ph[k] #phr[k] - list of phrases for tweet number k
	pos_sim = 0
	neg_sim = 0 
	for i in phr[k]:
		#print i
		phrase_words = i.split()
		#print phrase_words
		try:
			word_sum = (model[phrase_words[0]]+ model[phrase_words[1]])/2
			pos_sim = pos_sim + (1 - spatial.distance.cosine(word_sum,vec_pos))
			#print "pos_sim: " + str(pos_sim)
			neg_sim = neg_sim + (1 - spatial.distance.cosine(word_sum,vec_neg))
			#print "neg_sim:" + str(neg_sim)
		except:
			not_found_counter = not_found_counter + 1
			pass
	#print "pos_sim for tweet:" + str(pos_sim)
	#print "neg_sim for tweet:" + str(neg_sim)
	if pos_sim>neg_sim:
		List_SO.append(pos_sim-neg_sim)
		List_pred.append('positive')
	elif neg_sim>pos_sim:
		List_SO.append(pos_sim-neg_sim)
		List_pred.append('negative')
	else:
		List_SO.append(0)
		List_pred.append('neutral')


#print len(List_pred)
#print len(List_SO)

# Appending the Semantic Orientation of the Emoticons from a csv file (see emoticons_score_word2vec.py)
df_emo = pd.read_csv('C:\Users\Aman Garg\Desktop\Project\Codes\Emoticon_score.csv')
emo_list = df_emo['Emoticon_score'].values
numpy_so = np.array(List_SO)
numpy_so = numpy_so + emo_list[:8000]
List_SO = numpy_so.tolist()

df = pd.DataFrame({'label':List_pred, 'similarity': List_SO})
#print df.head(10)

df.to_csv('word2vec_result.csv')

#Confusion_Matrix = [638, 835
#					1297,3652]




