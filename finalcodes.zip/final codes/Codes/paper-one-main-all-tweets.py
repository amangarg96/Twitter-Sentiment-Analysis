# Takes Dictionary of phrases (json) as input and calculates the Semantic Orientation (SO) of the tweet using the Wikipedia corpus.
# Stores the SO as a dictionary in a json file
# Link to Wikipedia Corpus - http://www.cs.upc.edu/~nlp/wikicorpus/ (English raw_text version)

import pandas as pd
import math
import json
import io
import csv
import multiprocessing

# Our defined functions
from SemOrient1 import SemOrient1 # SemOrient{1,2,3,4} calculates SO for 1/4th of the Wikipedia corpus. To be employed simultaneously using multiprocessing
from SemOrient2 import SemOrient2
from SemOrient3 import SemOrient3
from SemOrient4 import SemOrient4
from string_freq_calc import string_freq_calc

#import time

#opening file and extracting sentences. storing the sentences in the list named match.
#t = time.time()

if __name__=='__main__': #Keep this program as main, otherwise multi-processing step generates error
    
    #Loads dictionary of phrases with the tweet number as its key
    ff=open('C:\Users\Aman Garg\Downloads\phrases_final_2.json','r')
    ph=json.load(ff)
    so={}
    solist=[]
    #phr ={}
    phr=ph
    
    # For taking a range of tweets, comment out phr=ph, uncomment phr = {}
    # for i in range(6700,7400):
    #     k=unicode(i)
    #     phr[k]=ph[k]
        
        
    #CALCULATION OF SEMANTIC ORIENTATION
    pos_seed = 'good' 
    neg_seed = 'bad'

    # Calculate frequency of pos_seed and neg_seed in the Wikipedia corpus
    pos_count = string_freq_calc(pos_seed) 
    neg_count = string_freq_calc(neg_seed)
    
    for i in phr:
        if phr[i]!=[]:
            for p in phr[i]:
                print p
                print i
                pl=str(p)

                #Some phrases have encoding issues, so we are ignoring phrases with such issues
                try:
                    pl=str(p.encode('utf-8'))
                except:
                    pass
                
                #Code for calculating Semantic Orientation with 4 Processes begins
                phrase = pl
                phrase = phrase.replace("\u002c","")
                phrase = phrase.replace("\u2019s","")
                

                Array_1 = multiprocessing.Array('d',2)
                Array_2 = multiprocessing.Array('d',2)
                Array_3 = multiprocessing.Array('d',2)
                Array_4 = multiprocessing.Array('d',2)

                t1 = multiprocessing.Process(target=SemOrient1,args = (phrase,pos_seed,neg_seed,Array_1,))
                t2 = multiprocessing.Process(target=SemOrient2,args = (phrase,pos_seed,neg_seed,Array_2,))
                t3 = multiprocessing.Process(target=SemOrient3,args = (phrase,pos_seed,neg_seed,Array_3,))
                t4 = multiprocessing.Process(target=SemOrient4,args = (phrase,pos_seed,neg_seed,Array_4,))

                t1.start()
                t2.start()
                t3.start()
                t4.start()

                t1.join()
                t2.join()
                t3.join()
                t4.join()
                
                # combining counts from all 4 processes
                phrase_post_count = Array_1[0] + Array_2[0] + Array_3[0] + Array_4[0]
                phrase_neg_count = Array_1[1] + Array_2[1] + Array_3[1] + Array_4[1]

                # 0.01 means no occurence. So if both (phrase,good) and (phrase,bad) not found, give SO values of zero (neutral)
                if phrase_post_count == 0.01 and phrase_neg_count == 0.01:
                    SO = 0
                else:
                    SO = math.log(((phrase_post_count * neg_count) / (phrase_neg_count*pos_count)),2) # Log Base 2, as used in paper
                
                #Semantic Orientation calculated
                
                solist.append(SO)
            
        so[i]=solist
        solist=[]

    # print so    #Dictionary containing calculated semantic orientation for each individual phrase
    
    
    sent_so={}

    for i in so:
        sent_so[i]=(sum(so[i]))
        
    # print sent_so     #Dictionary containing sum of semantic orientation for each tweet
    
    filen='SO_TWEETS_6700_7400.json'
    f=open(filen,'w')
    json.dump(sent_so,f)
