# -*- coding: utf-8 -*-
"""
Uses only the adjectives instead of phrases to classify the tweets. 
words_adjective.json contains adjective corresponding to tweets. See code - adjective_extraction.py
Semantic Orientation scores are calculated using word2vec vectorization of adjectives and seed words.
"""

import pandas as pd 
from scipy import spatial 
import gensim.models
import json
import numpy as np 
ff=open('C:\Users\Aman Garg\Desktop\Project\Codes\words_adjective.json','r') #Opening json file containing adjectives extracted from tweets
ad=json.load(ff)
so={}
solist=[]
adj={}
model = gensim.models.KeyedVectors.load_word2vec_format('C:\Users\Aman Garg\Desktop\Project\Codes\\GoogleNews-vectors-negative300.bin', binary=True)
pos_seed = 'good'
neg_seed = 'bad'
vec_pos = model[pos_seed]
vec_neg = model[neg_seed]
List_pred = []
List_SO = []
print len(adj)
count = 0
for j in range(8179):
	k=unicode(j)
	adj[k]=ad[k] 
	pos_sim = 0
	neg_sim = 0
        
	for i in adj[k]:
             
		
		try:
                  
			adj_val=model[i]
			pos_sim = pos_sim + (1 - spatial.distance.cosine(adj_val,vec_pos)) #finds cosine similarity of the adjectives with 'good'
			
			neg_sim = neg_sim + (1 - spatial.distance.cosine(adj_val,vec_neg)) #finds cosine similarity of the adjectives with 'bad'
			
		except:
                 print("no adj found")
                 print i
			
	
	if pos_sim>neg_sim:
		List_SO.append(pos_sim-neg_sim)
		List_pred.append('positive')
	elif neg_sim>pos_sim:
		List_SO.append(pos_sim-neg_sim)
		List_pred.append('negative')
	else:
		List_SO.append(0)
		List_pred.append('neutral')
print len(List_pred)
print len(List_SO)
df = pd.DataFrame({'label':List_pred, 'similarity': List_SO})
print df.head(100)
df.to_csv('word2vec_result_adj.csv') #Stores the SO score of all the tweets in a csv file
