# -*- coding: utf-8 -*-

# Preprocessing/cleaning step of tweets.
# Removes the entries with ‘Not Available’ tweets , and keeps only entries with sentiment ‘positive’ or ‘negative’
# Reduce tweet to lower case
# Replace hyperlinks with ‘||U||’
# Replace target name ‘@user’ with ‘||T||’
# Remove Hashtags
# Remove addition whitespaces.
# Replace positive sentiment emoticons with ‘||PE||’ and negative one with ‘||NE||’, based on the list ‘EmoticonSentimentLexicon.txt’
# Replace acronyms with full forms based on ‘InternetSlangAcronyms.txt’
# Remove punctuations  ‘    \' " ? , . ; & ( ) { } [ ] ! : -    ‘


import pandas as pd 
import re

def getStopWordList(stopWordListFP):

    stopWords = []
    stopWords.append('||T||')
    stopWords.append('||U||')

    fp = open(stopWordListFP, 'r')
    line = fp.readline()
    while line:
        word = line.strip()
        stopWords.append(word)
        line = fp.readline()
    fp.close()
    return stopWords

def getEmoticonList(emoticonListFP): # input - emoticonList File Position (FP), returns a list of Emoticons
    emoticonList = {}

    fp = open(emoticonListFP, 'r')
    line = fp.readline()
    while line:
        word = line.strip()
        word = word.split('\t')
        emoticonList[word[0]] = word[1]
        line = fp.readline()
    fp.close()
    return emoticonList

def getAcronymList(acronymListFP):
    acronymList = {}

    fp = open(acronymListFP, 'r')
    line = fp.readline()
    while line:
        word = line.strip()
        word = word.split('\t')
        acronymList[word[0]] = word[1]
        line = fp.readline()
    fp.close()
    return acronymList

def getNegativeWords(negativeListFP):
    negativeWords = []

    fp = open(negativeListFP, 'r')
    line = fp.readline()
    while line:
        word = line.strip()
        negativeWords.append(word)
        line = fp.readline()
    fp.close()
    return negativeWords




filename = 'final_set_using.csv'
#filename = 'C:\Users\Aman Garg\Desktop\Project\Code\imjalpreet-TwitterSentimentAnalysis-c10ea3a\data\training.tsv'
F = pd.read_csv(filename,header=None)
headers_list = 'index sentiment tweet'.split()
F.columns = headers_list #Renaming column labels




F = F.drop('index'.split(),axis='columns') # Keeping only sentiment and tweet 
F = F[F['tweet']!='Not Available'] # Dropping rows with no tweets 


# positive - 2833. neutral - 1367, negative - 1064, objective - 1005
F = F[F['sentiment']!='objective']
F = F[F['sentiment']!='neutral']
F = F[F['sentiment']!='objective-OR-neutral']
# Keeping only positive and negative sentiments

l=[]

count = 0
for tweet in F['tweet']:
	
	# 		* = 0 or more...
	#		+ = 1 or more...
	#		? = 0 or 1 of preceding character
	#		^ -> Matches start of the string		 
    count = count + 1
    #tweet=tweet.decode('unicode_escape').encode('ascii','ignore')
    # unicode to ascii (For \u002c and \u2019 in tweets)

    tweet = tweet.lower()

    """
	Convert www.* or https?://* to ||U|| # Update (19th June) - simply removing Hyperlinks
	"""
    tweet = re.sub('((www\.[^\s]+)|(https?://[^\s]+))', '', tweet)

    """
    Convert @username to ||T|| # Update (19th June) - simply removing @ tages
	"""
    tweet = re.sub('@[^\s]+', '', tweet)

    """
    Replace #word with word
    """
    tweet = re.sub(r'#([^\s])', r'\1', tweet)

    """
    Remove additional white spaces
    """
    tweet = re.sub('[\s]+', ' ', tweet)

    """
    Remove \u002c and \u2019s from tweets
    """

    tweet = tweet.replace('\u002c','')
    tweet = tweet.replace('\u2019s','')

    l.append(tweet)
	#print l

F['tweet'] = l


# Replacing Emoticons, Acronyms and Punctuations 


emoticons = getEmoticonList('EmoticonSentimentLexicon.txt')
acronyms = getAcronymList('InternetSlangAcronyms.txt')
#negative_words = getNegativeWords('negativeWords.txt') # Negative words left out for the time being, can be replaced by other words like NEGATIVE

#print F.info()
l = []
for tweet in F['tweet']:
	#print "tweet type:" + str(type(tweet))
	if type(tweet) == type('abc'):
		words = tweet.split()
	new_words = []
	for word in words:
		if emoticons.has_key(word):
			if emoticons[word] == '1':
				new_words.append('') # Update (19th June) - Removing emoticons instead of keeping ||PE|| and ||NE||
			elif emoticons[word] == '-1':
				new_words.append('') #Removing Negative Emoticons (||NE||)
		elif acronyms.has_key(word):
			word = acronyms[word].split(' ')
			new_words.extend(word)
		else:	
			word = word.strip('\'"?,.;&(){}[]!:-')
			new_words.append(word)
	new_words = ' '.join(new_words)
	l.append(new_words)
#print F.tail()
F['tweet'] = l
#print F.tail()
#print '#######################'
#print F['tweet'].describe()
#G = pd.read_csv(filename,header=None,index_col=0)
#print F.head()
#print G.head()


F.to_csv('final_set_using_processed.csv')