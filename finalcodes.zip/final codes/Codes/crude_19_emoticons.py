# -*- coding: utf-8 -*-
"""
Created on Tue Jun 27 16:12:29 2017

@author: Amit Behera
"""
# Code to calculate the emoticon frequencies and also the type of emoticon - positve
# or negative in each of the tweets
# The final output is a dataframe

import pandas as pd
import nltk
from nltk.util import ngrams
from collections import Counter


filename = 'C:\Users\Amit Behera\.spyder\PROJECT\!Finals\data\Final_set_tags.csv'
F = pd.read_csv(filename,header=None)#,delimiter='\t')
headers_list = 'L1 sentiment tweet'.split()
F.columns = headers_list #Renaming column labels


F = F.drop('L1'.split(),axis='columns') # Keeping only sentiment and tweet 
#F = F[F['tweet']!='Not Available'] # Dropping rows with no tweets 
k=0

#file2='C:\Users\Amit Behera\.spyder\PROJECT\!Finals\data\Final_set_tags_emoticon_freq.csv'
#ff=open(file2,'w')
emo_list=[]
pos=0.087
neg=-0.031
s=0
fcnt=[]
for f in F['tweet']:
    #f='||t|| hate my lif | ||ne|| e because i canot see you at the roskilde festival on saturday promise me to come back again soon ||pe|| ||pe|| ||pe||'
    #print f
    k=k+1
    #if k==100:        break
    
    unigram = nltk.word_tokenize(f)
    #bigram = ngrams(unigram,2)
    #print unigram
    #print bigram
    c=Counter(unigram)
    #d=Counter(bigram)
    #print c
    cnt=c['||pe||']-c['||ne||']
    emo_list.append(cnt)
    #print cnt
    if cnt>0:
        s=cnt*pos
    else:
        s=cnt*neg
    fcnt.append(s)
    s=0
    
df=pd.DataFrame({'Tweets':F['tweet'],'Emoticon_freq':fcnt})

    