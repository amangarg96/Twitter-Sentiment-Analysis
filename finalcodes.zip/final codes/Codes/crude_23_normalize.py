# -*- coding: utf-8 -*-
"""
Created on Thu Jun 29 16:33:51 2017

@author: Amit Behera
"""
# Code to normalize the Semantic Orientation scores and word2vec scores 
# and calculatimg the average of these 2 model scores andstoring them 
# in the form of a pandas Dataframe

from __future__ import division
import pandas as pd
import numpy as np

fil1='C:\Users\Amit Behera\.spyder\PROJECT\!Finals\data\So_tweets\SO_TWEETS.csv'
fil2='C:\Users\Amit Behera\.spyder\PROJECT\!Finals\data\word2vec_result.csv'
fil3='C:\Users\Amit Behera\.spyder\PROJECT\!Finals\data\Final_set.csv'
df1=pd.read_csv(fil1,delimiter=',')
df2=pd.read_csv(fil2,delimiter=',')
df3=pd.read_csv(fil3,delimiter=',',header=None)
print df1.head()
print df2.head()
print df3.head()
df1=df1.iloc[0:8179,:]
a=df1['No. Tweet']
b=df1['SO']
df2=df2.iloc[0:8179,:]
df3=df3.iloc[0:8179,:]
c=df3[1]
d=df2['similarity']


b=np.array(b)
r1=max(max(b),-min(b))
print r1
r2=max(max(d),-min(d))
print r2
bn=b/r1
dn=d/r2
e=0.5*dn+0.5*bn


df=pd.DataFrame({'No. Tweet':a,'Label':c,'SO':b,'word2vec':d,'SO_n':bn,'word2vec_n':dn,'Average':e})
df=df[df['Average']!=0]
print df.info()
print df.head()
'''
df['Normalized']=xx
print df.head()'''
fil='C:\Users\Amit Behera\.spyder\PROJECT\!Finals\data\So_tweets\SO_TWEETS_normalized.csv'
df.to_csv(fil,delimiter='\t',index=False)
