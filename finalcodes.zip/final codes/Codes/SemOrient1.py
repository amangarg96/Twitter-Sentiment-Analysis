# Calculates occurrences in first 1-41 files (Wikipedia corpus has 164 in total)

import re
import math
import multiprocessing
def SemOrient1(phrase,pos_seed,neg_seed,Array_1):
    # converting phrase and seeds to lower case
    phrase = phrase.lower()
    pos_seed = pos_seed.lower()
    neg_seed = neg_seed.lower()

    phrase_post_count_1 = 0.01 # Arbitrary choice 0.01 to avoid division by 0
    phrase_neg_count_1 = 0.01

    start = 0
    end = 10000

    for x in range(41):
        filename = "C:\Users\Aman Garg\Documents\\raw-en\englishText_%d_%d" %(start,end)
        file=open(filename,"r")
        sent=[line.lower() for line in file] #Storing sentences as lower case with lower() function
        se=' '.join(sent)
        match=re.split(r'[.!?]', se)

        #elapsed = time.time() - t
        #print elapsed
        # elapsed - 0.57 secs

        for i in match:
            if phrase in i and pos_seed in i: # Checks co-occurence of phrase and positive seed in a single sentence
                phrase_post_count_1 = phrase_post_count_1 + 1
            if phrase in i and neg_seed in i: #Checks co-occurence of phrase and negative seed in a single sentence
                phrase_neg_count_1 = phrase_neg_count_1 + 1
            
            
        start = start + 10000
        end = end + 10000    
    
    [Array_1[0],Array_1[1]]=[phrase_post_count_1,phrase_neg_count_1]
    
    return