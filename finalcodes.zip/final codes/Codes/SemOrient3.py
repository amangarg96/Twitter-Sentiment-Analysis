#Calculates occurences in 83-123 files from Wikipedia Corpus (out of 164)

import re
import math

def SemOrient3(phrase,pos_seed,neg_seed,Array_3):
    # converting phrase and seeds to lower case
    phrase = phrase.lower()
    pos_seed = pos_seed.lower()
    neg_seed = neg_seed.lower()

    phrase_post_count_3 = 0.00
    phrase_neg_count_3 = 0.00

    start = 820000
    end = 830000

    for x in range(82,123):
        filename = "C:\Users\Aman Garg\Documents\\raw-en\englishText_%d_%d" %(start,end)
        file=open(filename,"r")
        sent=[line.lower() for line in file] #Storing sentences as lower case with lower() function
        se=' '.join(sent)
        match=re.split(r'[.!?]', se)

        #elapsed = time.time() - t
        #print elapsed
        # elapsed - 0.57 secs

        for i in match:
            if phrase in i and pos_seed in i: # Checks co-occurence of phrase and positive seed in a single sentence
                phrase_post_count_3 = phrase_post_count_3 + 1
            if phrase in i and neg_seed in i: #Checks co-occurence of phrase and negative seed in a single sentence
                phrase_neg_count_3 = phrase_neg_count_3 + 1
            # pos_count_3 = pos_count_3 + i.count(pos_seed) # Counts number of substrings in string
            # neg_count_3 = neg_count_3 + i.count(neg_seed) # ''       ''    ''   ''      '' ''
            # phrase_count_3 = phrase_count_3 + i.count(phrase) # ''   ''    ''  ''        ''  ''
            
            
        start = start + 10000
        end = end + 10000    
    # print "Phrase freq 3:" + str(phrase_count_3)
    # print "Positive Seed count 3:" + str(pos_count_3)
    # print "Negative Seed count 3:" + str(neg_count_3)
    # print "Phrase,Positive Seed count 3:" + str(phrase_post_count_3)
    # print "Phrase,Negative Seed count 3:" + str(phrase_neg_count_3)

    #global List_3
    [Array_3[0],Array_3[1]]=[phrase_post_count_3,phrase_neg_count_3]#,Array_3[2],Array_3[3],Array_3[4]] = [phrase_post_count_3,phrase_neg_count_3,phrase_count_3,pos_count_3,neg_count_3]

    # if phrase_post_count_3 == 0.01 and phrase_neg_count_3 == 0.01:
    #     SO = 0
    # else:
    #     SO = math.log(((phrase_post_count_3 * neg_count_3) / (phrase_neg_count_3*pos_count_3)),2) # Log Base 2, as used in paper
    return