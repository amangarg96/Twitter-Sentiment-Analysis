# -*- coding: utf-8 -*-

#Identifies positive and negative emoticons and adds a score (see line 18 and 19) to the SO of the tweet (stored in csv)

import pandas as pd
import nltk
from nltk.util import ngrams
from collections import Counter


filename = 'C:\Users\Aman Garg\Desktop\Project\Codes\Final_set_tags.csv'
F = pd.read_csv(filename,header=None)#,delimiter='\t')
headers_list = 'L1 sentiment tweet'.split()
F.columns = headers_list #Renaming column labels


F = F.drop('L1'.split(),axis='columns') # Keeping only sentiment and tweet 
pos=0.087 #Median SO value of positive labeled tweets
neg= -0.031 #Median SO value of negative labeled tweets
score = 0
fcnt=[]
pos_emo_count = []
neg_emo_count = []
score_list = []
for f in F['tweet']:
    #f='||t|| hate my lif | ||ne|| e because i canot see you at the roskilde festival on saturday promise me to come back again soon ||pe|| ||pe|| ||pe||'
    #print f
    unigram = nltk.word_tokenize(f)
    c=Counter(unigram)
    pos_emo_count.append(c['||pe||'])
    neg_emo_count.append(c['||ne||'])
    score=c['||pe||']*pos+c['||ne||']*neg
    score_list.append(score)
    s=0
    
df=pd.DataFrame({'Tweets':F['tweet'],'Emoticon_score':score_list,'Positive Emoticon Count':pos_emo_count,'Negative Emoticon Count':neg_emo_count})
df.to_csv('Emoticon_score.csv')
    