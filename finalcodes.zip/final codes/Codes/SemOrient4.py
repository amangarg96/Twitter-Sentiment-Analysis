#Calculates occurences in 124-164 files from Wikipedia Corpus (out of 164)

import re
import math

def SemOrient4(phrase,pos_seed,neg_seed,Array_4):
    # converting phrase and seeds to lower case
    phrase = phrase.lower()
    pos_seed = pos_seed.lower()
    neg_seed = neg_seed.lower()

    phrase_post_count_4 = 0.00 
    phrase_neg_count_4 = 0.00

    start = 1230000
    end = 1240000

    for x in range(123,164):
        filename = "C:\Users\Aman Garg\Documents\\raw-en\englishText_%d_%d" %(start,end)
        file=open(filename,"r")
        sent=[line.lower() for line in file] #Storing sentences as lower case with lower() function
        se=' '.join(sent)
        match=re.split(r'[.!?]', se)

        #elapsed = time.time() - t
        #print elapsed
        # elapsed - 0.57 secs

        for i in match:
            if phrase in i and pos_seed in i: # Checks co-occurence of phrase and positive seed in a single sentence
                phrase_post_count_4 = phrase_post_count_4 + 1
            if phrase in i and neg_seed in i: #Checks co-occurence of phrase and negative seed in a single sentence
                phrase_neg_count_4 = phrase_neg_count_4 + 1
            
        start = start + 10000
        end = end + 10000    
    
    [Array_4[0],Array_4[1]]=[phrase_post_count_4,phrase_neg_count_4]

    return