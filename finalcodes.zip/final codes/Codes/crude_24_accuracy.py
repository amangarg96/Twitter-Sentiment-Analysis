# -*- coding: utf-8 -*-
"""
Created on Fri Jun 30 10:07:56 2017

@author: Amit Behera
"""


''' Code to calculate confusion matrix, precision, recall, f1 score and
 accuracy scores between the true labels and predicted labels from model 3'''

import numpy as np
import pandas as pd
import sklearn.metrics as met


fil='C:\Users\Amit Behera\.spyder\PROJECT\!Finals\data\So_tweets\SO_TWEETS_normalized.csv'
df=pd.read_csv(fil,delimiter=',')
print df.head()

df.ix[df['Average']>0,'Average'] = 1
df.ix[df['Average']<0,'Average'] = -1
y_pred=df['Average']
a=df['Label']
df['Label']=df['Label'].replace(['negative'],-1)
df['Label']=df['Label'].replace(['positive'],1)
y_true=df['Label']
y_pred=np.array(y_pred)
y_pred=y_pred.astype(int)
y_true=np.array(y_true)
print df.head()


#print met.accuracy_score(y_true,y_pred)  #65.62
cm=met.confusion_matrix(y_true,y_pred)
print cm
#cc=prf(y_true,y_pred)
#print cc
p=met.precision_score(y_true,y_pred)
print 'Precision:%f'%p
rc=met.recall_score(y_true,y_pred)
print 'Recall: %f'%rc
f1=met.f1_score(y_true,y_pred)
print 'f1 Score: %f'%f1
acc=met.accuracy_score(y_true,y_pred)
print 'Accuracy: %f'%acc