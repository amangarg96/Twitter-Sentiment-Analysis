# -*- coding: utf-8 -*-

# Builds a dictionary of adjectives, to be used as seed words
# Score: Similarity(adj,'good') - Similarity(adj,'bad')

import gensim
import pandas as pd
import nltk
from scipy import spatial

# Loading pre-trained word2vec model, takes a couple of minutes to load
model = gensim.models.KeyedVectors.load_word2vec_format('C:\Users\Amit Behera\.spyder\PROJECT\GoogleNews-vectors-negative300.bin', binary=True)

F = pd.read_csv('C:\Users\Amit Behera\.spyder\PROJECT\!Finals\Preprocessing\Final_set.csv',header=None)
F=F[2]
adjective=[]
i=0


for i in range(len(F)):
    try:
        if F[i]!=' ':
            
            word=nltk.word_tokenize(F[i])
            tag=nltk.pos_tag(word)
            #print tag
            j=0
            for j in range(len(tag)):
                if tag[j][1]=='JJ':
                    adjective.append(tag[j][0])
    except:
        pass      
#print adjective
#print len(adjective)    #14912
adjective=list(set(adjective))
#print adjective
#print(len(adjective))   #3575


so_pos_adj={}
so_neg_adj={}
k=0
pos_seed=model['good']
neg_seed=model['bad']
so_adj={}

for k in range(len(adjective)):
    try:
        posem=1-spatial.distance.cosine(model[adjective[k]],pos_seed)
        so_pos_adj[adjective[k]]=posem
        nesem=1-spatial.distance.cosine(model[adjective[k]],neg_seed)
        so_neg_adj[adjective[k]]=nesem
        diff=posem-nesem
        so_adj[adjective[k]]=diff
    except:
        pass

pos_adj=pd.DataFrame(so_pos_adj.items(),columns=['adjective','positive SO'])
neg_adj=pd.DataFrame(so_neg_adj.items(),columns=['adjective','negative SO'])
            
adj=pd.DataFrame(so_adj.items(),columns=['adjective','SO'])
adj.to_csv('Adjective_SO_word2vec.csv')

    
